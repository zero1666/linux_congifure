***************
Developer guide
***************

.. toctree::
   :maxdepth: 2
   :glob:

   develop/segments
   develop/listers
   develop/local-themes
   develop/extensions
   develop/tips-and-tricks
