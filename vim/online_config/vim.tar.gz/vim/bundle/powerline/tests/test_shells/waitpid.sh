#!/bin/sh
while ! test -e pid ; do
	sleep 0.1s
done
